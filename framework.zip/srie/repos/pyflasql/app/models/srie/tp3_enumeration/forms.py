# This file is part of PyFlaSQL.
# Original author: Raphael Viera (raphael.viera@emse.fr)
# Contribution : ISMIN student X (ismin.student@etu.emse.fr)
# License: check the LICENSE file.
"""
Create forms to be passed to the frontend
"""
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, IntegerField
from wtforms.validators import DataRequired, Email, InputRequired, Length, ValidationError, NumberRange


# to be implemented
class Enum4LinuxForm(FlaskForm):
    target = StringField('Target (IP Address or Hostname)', validators=[DataRequired(), Length(min=2, max=255)])
    submit = SubmitField('Run Enum4Linux')

class NBTSCanForm(FlaskForm):
    target_range = StringField('Target Range (e.g., 192.168.1.0/24)', 
                               validators=[DataRequired(), Length(min=7, max=18)])
    submit = SubmitField('Run NetBIOS Scan')

class BannerGrabbingForm(FlaskForm):
    target = StringField('Target (IP Address or Hostname)', 
                         validators=[DataRequired(), Length(min=2, max=255)])
    port = IntegerField('Port Number', 
                        validators=[DataRequired(), NumberRange(min=1, max=65535)])
    submit = SubmitField('Grab Banner')