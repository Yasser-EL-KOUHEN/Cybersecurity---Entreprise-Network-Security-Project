# This file is part of PyFlaSQL.
# Original author: Raphael Viera (raphael.viera@emse.fr)
# Contribution : ISMIN student X (ismin.student@etu.emse.fr)
# License: check the LICENSE file.
"""
Create forms to be passed to the frontend
"""
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Email, InputRequired, Length, ValidationError


# to be implemented
class SSHForm(FlaskForm):
    target = StringField('Target (IP Address or Hostname)', validators=[DataRequired(), Length(min=2, max=255)])
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=50)])
    submit = SubmitField('Connect via SSH')

class FTPForm(FlaskForm):
    target = StringField('Target (IP Address or Hostname)', validators=[DataRequired(), Length(min=2, max=255)])
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=50)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=2, max=50)])
    submit = SubmitField('Connect via FTP')