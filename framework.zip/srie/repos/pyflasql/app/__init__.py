from .models.app import PyFlaSQL

pyflasql_obj = PyFlaSQL()
PyFlaSQL = pyflasql_obj.myapp